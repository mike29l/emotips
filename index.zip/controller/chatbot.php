<?php
header('Content-Type: application/json');

// 1. Configuración
define('CLAUDE_URL', 'https://api.anthropic.com/v1/messages');
define('API_KEY', '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'); // ¡Reemplaza esto!

// 2. Obtener y validar input
$input = json_decode(file_get_contents('php://input'), true);
$mensajeUsuario = trim($input['message'] ?? '');

if (empty($mensajeUsuario)) {
    http_response_code(400);
    echo json_encode(["error" => "Por favor escribe tu mensaje"]);
    exit;
}

// 3. Construir payload CORRECTO para Claude
$data = [
    "model" => $input['model'] ?? "claude-3-haiku-20240307",
    "max_tokens" => 300,
    "system" => "Eres 'Esperanza', asistente emocional para adolescentes. Responde en español con empatía, en 2-3 frases breves. Usa emojis relevantes. 💙", // Movido aquí
    "messages" => [
        ["role" => "user", "content" => $mensajeUsuario] // Solo mensaje del usuario
    ],
    "temperature" => 0.7
];

// 4. Enviar solicitud (igual que antes)
$ch = curl_init(CLAUDE_URL);
curl_setopt_array($ch, [
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => json_encode($data),
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_HTTPHEADER => [
        "Content-Type: application/json",
        "x-api-key: " . API_KEY,
        "anthropic-version: 2023-06-01"
    ],
    CURLOPT_TIMEOUT => 30
]);

$response = curl_exec($ch);
$error = curl_error($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

// 5. Manejo de errores
if ($error) {
    http_response_code(500);
    echo json_encode(["error" => "Error de conexión: $error"]);
    exit;
}

if ($httpCode !== 200) {
    http_response_code($httpCode);
    $errorData = json_decode($response, true);
    echo json_encode(["error" => $errorData['error']['message'] ?? "Error en la API"]);
    exit;
}

// 6. Procesar respuesta exitosa
$json = json_decode($response, true);
echo json_encode([
    "respuesta" => $json['content'][0]['text'] ?? "No pude generar una respuesta",
    "meta" => [
        "modelo" => $data['model'],
        "tokens" => $json['usage']['output_tokens'] ?? 0
    ]
]);
?>
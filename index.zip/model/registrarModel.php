<?php
require_once("../config/conexion.php");

class RegistrarModel {
    private $dbh;

    public function __construct() {
        $this->dbh = (new Conectar())->Conexion();  // Establecemos la conexión
    }

    // Método para registrar un nuevo usuario
    public function registrarUsuario($usuario, $nombre, $contraseña, $rol) {
        
        // Validar que el rol es válido (1 para cliente, 2 para profesor)
        if ($rol != 1 && $rol != 2) {
            return "Rol inválido.";
        }

        // Hashear la contraseña
        $contraseñaHash = password_hash($contraseña, 2);

        // SQL para insertar el usuario en la tabla `rol` sin el campo `id` (lo genera MySQL automáticamente)
        $sql = "INSERT INTO rol ( nombre, contrasenia, usuario, id_rol) VALUES ( :nombre, :contrasenia,:usuario, :id_rol)";

        try {
            // Preparar la consulta SQL
            $stmt = $this->dbh->prepare($sql);

            // Enlazar los parámetros con los valores correspondientes
            $stmt->bindParam(':usuario', $usuario, PDO::PARAM_STR);
            $stmt->bindParam(':nombre', $nombre, PDO::PARAM_STR);
            $stmt->bindParam(':contrasenia', $contraseñaHash, PDO::PARAM_STR);
            $stmt->bindParam(':id_rol', $rol, PDO::PARAM_INT);

            // Ejecutar la consulta
            $stmt->execute();
            return true; // Registro exitoso
        } catch (PDOException $e) {
            // Capturar y retornar el error si ocurre
            return "Error: " . $e->getMessage();
        }
    }
}
?>

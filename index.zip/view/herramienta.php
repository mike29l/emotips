<?php
session_start();

// Verificar si el usuario no ha iniciado sesión o no es un cliente
if (!isset($_SESSION['id'])) {
    header("Location: ../index.php");
    exit();
}

// Verificar si el usuario no tiene el rol de cliente (id_rol = 2)
if ($_SESSION['id_rol'] != "2") {
    header("Location: ../index.php");
    exit();
}

// El resto de tu código PHP y HTML para estas páginas
?>
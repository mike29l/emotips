<?php
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
header("Expires: 0");
session_start();

// Validación de sesión y rol
if (!isset($_SESSION['id'])) {
    header("Location: ../index.php");
    exit();
}

if ($_SESSION['id_rol'] != "2") {
    header("Location: ../index.php");
    exit();
}

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mi Espacio Seguro</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="icon" type="image/png" href=" ../img/brain_6302633.png">
    <style>
        /* Estilos generales */
        body {
            font-family: 'Nunito', sans-serif;
            background-color: #F8F9FF;
            color: #2E2E3A;
            margin: 0;
            padding: 0;
        }
                    @media screen and (min-width: 768px) {
                #chatbot {
                    max-width: 700px;
                }

                #chatbox {
                    height: 500px;
                }
            }


        header {
            background: white;
            padding: 15px 5%;
            box-shadow: 0 4px 20px rgba(108, 99, 255, 0.1);
            position: sticky;
            top: 0;
            z-index: 100;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .logo {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .logo i {
            color: #6C63FF;
            font-size: 24px;
        }

        .logo h1 {
            font-size: 20px;
            font-weight: 700;
            color: #6C63FF;
        }

        .user-nav {
            display: flex;
            align-items: center;
            gap: 20px;
        }

        .user-nav a {
            color: #2E2E3A;
            text-decoration: none;
            transition: color 0.3s ease;
            font-size: 14px;
        }

        .user-nav a:hover {
            color: #FF6584;
        }

        .logout-btn {
            padding: 10px 15px;
            background: #FF6584;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background 0.3s ease;
        }

        .logout-btn:hover {
            background: #E94E77;
        }

        /* Estilos del chatbot */
        #chatbot {
            margin: 40px auto;
            max-width: 600px;
            background: #fff;
            padding: 20px;
            border-radius: 15px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        #chatbox {
            height: 400px;
            overflow-y: auto;
            padding: 10px;
            background: #FAFAFA;
            border-radius: 10px;
        }

        .msg-user, .msg-bot {
            max-width: 80%;
            padding: 10px 15px;
            margin: 10px 0;
            border-radius: 15px;
            display: inline-block;
        }

        .msg-user {
            background: #6C63FF;
            color: white;
            align-self: flex-end;
            float: right;
            clear: both;
        }

        .msg-bot {
            background: #f1f1f1;
            color: #333;
            align-self: flex-start;
            float: left;
            clear: both;
        }

        #chatForm {
            margin-top: 15px;
            display: flex;
        }

        #userInput {
            flex: 1;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px 0 0 5px;
        }

        #chatForm button {
            padding: 10px 20px;
            border: none;
            background: #6C63FF;
            color: white;
            border-radius: 0 5px 5px 0;
        }
    </style>
</head>

<script>
// Evitar que el usuario regrese con el botón "Atrás"
history.pushState(null, null, location.href);
window.onpopstate = function () {
    history.go(1);
};
</script>

<body>
    <header>
        <div class="logo">
            <i class="fas fa-heart"></i>
            <h1>Mi Espacio Seguro</h1>
        </div>
        <div class="user-nav">
            <a href="#">Inicio</a>
            <a href="herramienta.php">Herramientas</a>
            <a href="perfil.php">Perfil</a>
            <form action="../controller/logout.php" method="post" style="display:inline;">
                <button type="submit" class="logout-btn">Cerrar sesión</button>
            </form>
        </div>
    </header>

    <main>
       

        <!-- Chat con Claude AI -->
        <section id="chatbot">
            <h3 style="text-align: center; color: #6C63FF;">💙 Asistente Emocional EMOTIPS</h3>
            <p style="text-align: center; font-size: 14px; color: #666;">Habla con tu asistente IA sobre cómo te sientes.</p>
            
            <div id="chatbox">
                <!-- Mensaje inicial del bot -->
                <div class="msg-bot">Hola <?php echo htmlspecialchars($_SESSION['nombre'] ?? 'amigo/a'); ?>, soy emotips, tu amigo virtual que te ayudara en lo que desees para tu bienestar 💙</div>
            </div>
            
            <form id="chatForm">
                <input type="text" id="userInput" placeholder="Escribe cómo te sientes..." required>
                <button type="submit">Enviar <i class="fas fa-paper-plane"></i></button>
            </form>
        </section>

        <script>
        // Historial de conversación (se almacena en memoria)
        let conversationHistory = [
            {
                role: "system",
                content: "Eres 'Claude', un asistente emocional compasivo para adolescentes. Responde con empatía en español, usando un tono cálido pero profesional. Limita tus respuestas a 2-3 frases breves. Usa emojis relevantes ocasionalmente. 💙"
            }
        ];

        // Enviar mensaje a Claude API
        document.getElementById('chatForm').addEventListener('submit', async function(e) {
    e.preventDefault();

    const input = document.getElementById('userInput');
    const mensaje = input.value.trim();
    
    // Validación más robusta en el frontend
    if (mensaje === "") {
        const chatbox = document.getElementById('chatbox');
        chatbox.innerHTML += `<div class="msg-bot" style="color:#FF6584">💡 Por favor, escribe tu mensaje antes de enviar</div>`;
        chatbox.scrollTop = chatbox.scrollHeight;
        input.focus();
        return;
    }

    // Resto del código...
    const chatbox = document.getElementById('chatbox');
    chatbox.innerHTML += `<div class="msg-user">${mensaje}</div>`;
    chatbox.scrollTop = chatbox.scrollHeight;

    input.value = "";
    input.disabled = true;
    document.querySelector('#chatForm button').innerHTML = '<i class="fas fa-spinner fa-spin"></i>';

    try {
        const response = await fetch('../controller/chatbot.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                message: mensaje,  // Cambiado de 'messages' a 'message'
                model: "claude-3-haiku-20240307"
            })
        });

        const data = await response.json();
        
        if (!response.ok) {
            throw new Error(data.error || "Error al procesar tu mensaje");
        }

        const respuesta = data.respuesta || "No recibí una respuesta válida";
        chatbox.innerHTML += `<div class="msg-bot">${respuesta}</div>`;
        
    } catch (error) {
        console.error("Error:", error);
        chatbox.innerHTML += `<div class="msg-bot" style="color:#FF6584">⚠️ ${error.message || "Error de conexión"}</div>`;
    } finally {
        chatbox.scrollTop = chatbox.scrollHeight;
        input.disabled = false;
        document.querySelector('#chatForm button').innerHTML = 'Enviar <i class="fas fa-paper-plane"></i>';
        input.focus();
    }
});

        // Auto-enfoque en el input al cargar
        document.addEventListener('DOMContentLoaded', () => {
            document.getElementById('userInput').focus();
        });
        </script>
    </main>
</body>
</html>